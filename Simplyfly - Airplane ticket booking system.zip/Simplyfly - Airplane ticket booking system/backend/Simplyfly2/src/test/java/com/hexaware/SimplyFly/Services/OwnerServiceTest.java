package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.OwnerDTO;
import com.hexaware.SimplyFly.DTO.OwnerProfileDTO;
import com.hexaware.SimplyFly.Models.OwnerEntity;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.OwnerRepository;
import com.hexaware.SimplyFly.Repositories.UserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OwnerServiceTest {

    @Mock
    private OwnerRepository ownerRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private OwnerService ownerService;

    private OwnerDTO ownerDTO;
    private UserEntity user;
    private OwnerEntity owner;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        user = new UserEntity();
        user.setUserId(1);
        user.setUserName("John Doe");
        user.setUserEmail("john@example.com");
        user.setUserContact(9876543210L);
        user.setUserPwd("password");

        owner = new OwnerEntity();
        owner.setId(101);
        owner.setAirlineName("IndiGo");
        owner.setLicenseNumber("LIC12345");
        owner.setUser(user);

        ownerDTO = new OwnerDTO();
        ownerDTO.setUserId(1);
        ownerDTO.setAirlineName("IndiGo");
        ownerDTO.setLicenseNumber("LIC12345");
    }

    @Test
    void testRegisterOwner_success() throws Exception {
        when(userRepository.findById(1)).thenReturn(Optional.of(user));
        when(ownerRepository.save(any(OwnerEntity.class))).thenReturn(owner);

        OwnerEntity result = ownerService.registerOwner(ownerDTO);

        assertNotNull(result);
        assertEquals("IndiGo", result.getAirlineName());
        assertEquals("LIC12345", result.getLicenseNumber());
        assertEquals(1, result.getUser().getUserId());

        verify(userRepository).findById(1);
        verify(ownerRepository).save(any(OwnerEntity.class));
    }

    @Test
    void testRegisterOwner_userNotFound() {
        when(userRepository.findById(1)).thenReturn(Optional.empty());

        Exception ex = assertThrows(Exception.class, () -> {
            ownerService.registerOwner(ownerDTO);
        });

        assertTrue(ex.getMessage().contains("User not found with ID"));
        verify(userRepository).findById(1);
        verify(ownerRepository, never()).save(any());
    }

    @Test
    void testGetOwnerProfile_success() throws Exception {
        when(userRepository.findById(1)).thenReturn(Optional.of(user));
        when(ownerRepository.findByUserUserId(1)).thenReturn(Optional.of(owner));

        OwnerProfileDTO result = ownerService.getOwnerProfile(1);

        assertNotNull(result);
        assertEquals("IndiGo", result.getAirlineName());
        assertEquals("LIC12345", result.getLicenseNumber());
        assertEquals("John Doe", result.getUserName());

        verify(userRepository).findById(1);
        verify(ownerRepository).findByUserUserId(1);
    }

    @Test
    void testGetOwnerProfile_userNotFound() {
        when(userRepository.findById(1)).thenReturn(Optional.empty());

        Exception ex = assertThrows(Exception.class, () -> {
            ownerService.getOwnerProfile(1);
        });

        assertTrue(ex.getMessage().contains("User not found with ID"));
        verify(userRepository).findById(1);
        verify(ownerRepository, never()).findByUserUserId(anyInt());
    }

    @Test
    void testGetOwnerProfile_ownerNotFound() {
        when(userRepository.findById(1)).thenReturn(Optional.of(user));
        when(ownerRepository.findByUserUserId(1)).thenReturn(Optional.empty());

        Exception ex = assertThrows(Exception.class, () -> {
            ownerService.getOwnerProfile(1);
        });

        assertTrue(ex.getMessage().contains("Owner not found for user ID"));
        verify(userRepository).findById(1);
        verify(ownerRepository).findByUserUserId(1);
    }
}

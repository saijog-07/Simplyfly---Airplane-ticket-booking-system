package com.hexaware.SimplyFly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplyFlyApplicationTests {

	@Test
	void contextLoads() {
	}

}

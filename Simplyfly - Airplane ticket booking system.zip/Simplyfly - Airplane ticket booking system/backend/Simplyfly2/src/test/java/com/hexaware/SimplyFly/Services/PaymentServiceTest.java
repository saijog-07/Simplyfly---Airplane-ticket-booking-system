package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.PaymentDTO;
import com.hexaware.SimplyFly.Exceptions.BookingNotFoundException;
import com.hexaware.SimplyFly.Exceptions.PaymentNotFoundException;
import com.hexaware.SimplyFly.Models.BookingEntity;
import com.hexaware.SimplyFly.Models.PaymentEntity;
import com.hexaware.SimplyFly.Repositories.BookingRepository;
import com.hexaware.SimplyFly.Repositories.PaymentRepository;
import com.hexaware.SimplyFly.Enums.PaymentType;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PaymentServiceTest {

    @Mock
    private BookingRepository bookingRepo;

    @Mock
    private PaymentRepository paymentRepo;

    @InjectMocks
    private PaymentService paymentService;

    private BookingEntity booking;
    private PaymentEntity payment;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        booking = new BookingEntity();
        booking.setBookingId(100);

        payment = new PaymentEntity();
        payment.setPaymentId(200);
        payment.setBooking(booking);
        payment.setAmount(999.99);
        payment.setPaymentDate(new Date());
        payment.setPaymentStatus("Success");
        payment.setPaymentType(PaymentType.CARD);
        payment.setTransactionId("TXN123456");
    }

    @Test
    void testGetPaymentByBookingId_success() {
        when(bookingRepo.findById(100)).thenReturn(Optional.of(booking));
        when(paymentRepo.findByBooking(booking)).thenReturn(Optional.of(payment));

        PaymentDTO result = paymentService.getPaymentByBookingId(100);

        assertNotNull(result);
        assertEquals(200, result.getPaymentId());
        assertEquals(100, result.getBookingId());
        assertEquals("TXN123456", result.getTransactionId());
        assertEquals("Success", result.getPaymentStatus());
        assertEquals(PaymentType.CARD, result.getPaymentType());
        verify(bookingRepo).findById(100);
        verify(paymentRepo).findByBooking(booking);
    }

    @Test
    void testGetPaymentByBookingId_bookingNotFound() {
        when(bookingRepo.findById(100)).thenReturn(Optional.empty());

        assertThrows(BookingNotFoundException.class, () -> {
            paymentService.getPaymentByBookingId(100);
        });

        verify(bookingRepo).findById(100);
        verify(paymentRepo, never()).findByBooking(any());
    }

    @Test
    void testGetPaymentByBookingId_paymentNotFound() {
        when(bookingRepo.findById(100)).thenReturn(Optional.of(booking));
        when(paymentRepo.findByBooking(booking)).thenReturn(Optional.empty());

        assertThrows(PaymentNotFoundException.class, () -> {
            paymentService.getPaymentByBookingId(100);
        });

        verify(bookingRepo).findById(100);
        verify(paymentRepo).findByBooking(booking);
    }
}

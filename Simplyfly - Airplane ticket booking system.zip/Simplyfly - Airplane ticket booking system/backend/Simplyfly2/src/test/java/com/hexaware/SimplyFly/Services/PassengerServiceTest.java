package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.PassengerDTO;
import com.hexaware.SimplyFly.Enums.Gender;
import com.hexaware.SimplyFly.Exceptions.BookingNotFoundException;
import com.hexaware.SimplyFly.Models.BookingEntity;
import com.hexaware.SimplyFly.Models.PassengerEntity;
import com.hexaware.SimplyFly.Repositories.BookingRepository;
import com.hexaware.SimplyFly.Repositories.PassengerRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class PassengerServiceTest {

    @Mock
    private BookingRepository bookingRepo;

    @Mock
    private PassengerRepository passengerRepo;

    @InjectMocks
    private PassengerService passengerService;

    private BookingEntity bookingEntity;
    private PassengerEntity passengerEntity;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        bookingEntity = new BookingEntity();
        bookingEntity.setBookingId(10);

        passengerEntity = new PassengerEntity();
        passengerEntity.setPasssengerId(1);
        passengerEntity.setPassengerName("Alice");
        passengerEntity.setPassengerAge(25);
        passengerEntity.setPassengerGender(Gender.FEMALE);
        passengerEntity.setSeatNo("12A");
        passengerEntity.setBooking(bookingEntity);
    }

    @Test
    void testGetPassengersByBookingId_success() {
        when(bookingRepo.findById(10)).thenReturn(Optional.of(bookingEntity));
        when(passengerRepo.findByBooking(bookingEntity)).thenReturn(List.of(passengerEntity));

        List<PassengerDTO> result = passengerService.getPassengersByBookingId(10);

        assertEquals(1, result.size());
        assertEquals("Alice", result.get(0).getPassengerName());
        assertEquals("12A", result.get(0).getSeatNo());
        assertEquals(10, result.get(0).getBookingId());
    }

    @Test
    void testGetPassengersByBookingId_notFound() {
        when(bookingRepo.findById(10)).thenReturn(Optional.empty());

        assertThrows(BookingNotFoundException.class, () -> {
            passengerService.getPassengersByBookingId(10);
        });
    }

    @Test
    void testGetBookedSeatsForFlight_success() {
        when(passengerRepo.findBookedSeatsByFlightIdWithBookedStatus(101L)).thenReturn(List.of("12A", "14B"));

        List<String> result = passengerService.getBookedSeatsForFlight(101L);

        assertEquals(2, result.size());
        assertTrue(result.contains("12A"));
        assertTrue(result.contains("14B"));
    }
}

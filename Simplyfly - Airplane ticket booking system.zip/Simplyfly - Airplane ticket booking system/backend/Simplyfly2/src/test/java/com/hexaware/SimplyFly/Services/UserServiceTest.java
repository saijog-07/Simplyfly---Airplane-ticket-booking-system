package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.*;
import com.hexaware.SimplyFly.Exceptions.UserNotFoundException;
import com.hexaware.SimplyFly.Mappers.UserMapper;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.UserRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class UserServiceTest {

    @Mock
    private UserRepository userRepo;
    @Mock
    private PasswordEncoder passwordEncoder;
    @Mock
    private UserMapper userMap;
    @InjectMocks
    private UserService userService;

    private UserDTO userDto;
    private UserEntity userEntity;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        userDto = new UserDTO();
        userDto.setUserId(1);
        userDto.setUserName("Sai");
        userDto.setUserEmail("sai@example.com");
        userDto.setUserPwd("pass");

        userEntity = new UserEntity();
        userEntity.setUserId(1);
        userEntity.setUserName("Sai");
        userEntity.setUserEmail("sai@example.com");
        userEntity.setUserPwd("encodedPass");
    }

    @Test
    void testRegisterUser_success() {
        when(userMap.DtoToUser(userDto)).thenReturn(userEntity);
        when(passwordEncoder.encode("pass")).thenReturn("encodedPass");
        when(userRepo.save(userEntity)).thenReturn(userEntity);
        when(userMap.UserToDto(userEntity)).thenReturn(userDto);

        UserDTO result = userService.RegisterUserService(userDto);

        assertEquals(userDto.getUserId(), result.getUserId());
        verify(passwordEncoder).encode("pass");
        verify(userRepo).save(userEntity);
    }

    @Test
    void testLoginUser_success() {
        LoginDTO loginDTO = new LoginDTO("sai@example.com", "pass");
        userEntity.setUserPwd("pass");

        when(userRepo.findByuserEmail("sai@example.com")).thenReturn(userEntity);
        when(userMap.UserToDto(userEntity)).thenReturn(userDto);

        UserDTO result = userService.LoginUserService(loginDTO);
        assertEquals("sai@example.com", result.getUserEmail());
    }

    @Test
    void testLoginUser_failure() {
        LoginDTO loginDTO = new LoginDTO("sai@example.com", "wrong");

        when(userRepo.findByuserEmail("sai@example.com")).thenReturn(userEntity);
        userEntity.setUserPwd("pass");

        assertThrows(UserNotFoundException.class, () -> {
            userService.LoginUserService(loginDTO);
        });
    }

    @Test
    void testGetProfile_success() {
        when(userRepo.findById(1)).thenReturn(Optional.of(userEntity));
        when(userMap.UserToDto(userEntity)).thenReturn(userDto);

        UserDTO result = userService.GetProfileService(1);
        assertEquals(1, result.getUserId());
    }

    @Test
    void testGetProfile_failure() {
        when(userRepo.findById(1)).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> {
            userService.GetProfileService(1);
        });
    }

    @Test
    void testUpdateProfile_success() {
        UserUpdateDTO updateDTO = new UserUpdateDTO();
        updateDTO.setUserName("New Sai");
        updateDTO.setUserEmail("new@example.com");

        when(userRepo.findById(1)).thenReturn(Optional.of(userEntity));
        when(userRepo.save(userEntity)).thenReturn(userEntity);
        when(userMap.UserToDto(userEntity)).thenReturn(userDto);

        UserDTO result = userService.updateProfileFields(1, updateDTO);
        assertEquals("sai@example.com", result.getUserEmail());
    }

    @Test
    void testForgotPassword_success() {
        ForgotPasswordDTO dto = new ForgotPasswordDTO();
        dto.setUserEmail("sai@example.com");
        dto.setUserName("Sai");
        dto.setUserPwd("newPass");

        when(userRepo.findByuserEmail("sai@example.com")).thenReturn(userEntity);
        when(userMap.UserToDto(userEntity)).thenReturn(userDto);
        when(userRepo.save(userEntity)).thenReturn(userEntity);

        UserDTO result = userService.forgotPasswordService(dto);
        assertNotNull(result);
    }

    @Test
    void testGetAllUsers_success() {
        List<UserEntity> userList = List.of(userEntity);
        when(userRepo.findAll()).thenReturn(userList);
        when(userMap.UserToDto(userEntity)).thenReturn(userDto);

        List<UserDTO> result = userService.getAllUsers();
        assertEquals(1, result.size());
    }
}

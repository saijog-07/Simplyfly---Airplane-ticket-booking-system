package com.hexaware.SimplyFly.Services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.hexaware.SimplyFly.DTO.*;
import com.hexaware.SimplyFly.Enums.UserType;
import com.hexaware.SimplyFly.Exceptions.*;
import com.hexaware.SimplyFly.Mappers.FlightMapper;
import com.hexaware.SimplyFly.Models.*;
import com.hexaware.SimplyFly.Repositories.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FlightServiceTest {

    @Mock
    private FlightRepository flightRepo;

    @Mock
    private UserRepository userRepo;

    @Mock
    private FlightMapper flightMapper;

    @InjectMocks
    private FlightService flightService;

    private UserEntity owner;
    private FlightEntity flightEntity;
    private FlightDTO flightDTO;
    private FlightUpdateDTO flightUpdateDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        owner = new UserEntity();
        owner.setUserId(1);
        owner.setUserType(UserType.OWNER);

        flightEntity = new FlightEntity();
        flightEntity.setFlightId(100);
        flightEntity.setSource("Mumbai");
        flightEntity.setDestination("Delhi");

        flightDTO = new FlightDTO();
        flightDTO.setFlightId(100);
        flightDTO.setSource("Mumbai");
        flightDTO.setDestination("Delhi");
        flightDTO.setOwnerId(1);

        flightUpdateDTO = new FlightUpdateDTO();
        flightUpdateDTO.setDepertureT(LocalDateTime.now().plusHours(1));
        flightUpdateDTO.setAvailSeats(50);
        flightUpdateDTO.setBaggage("20kg");
        flightUpdateDTO.setDestination("Bangalore");
        flightUpdateDTO.setSource("Hyderabad");
        flightUpdateDTO.setFare(2000.0);
        flightUpdateDTO.setTotalSeats(100);
    }

    @Test
    void testAddNewFlight_success() {
        when(userRepo.findById(1)).thenReturn(Optional.of(owner));
        when(flightMapper.DtoToFlight(flightDTO)).thenReturn(flightEntity);
        when(flightRepo.save(flightEntity)).thenReturn(flightEntity);
        when(flightMapper.FlightToDto(flightEntity)).thenReturn(flightDTO);

        FlightDTO result = flightService.AddNewFlight(flightDTO);
        assertEquals(flightDTO.getFlightId(), result.getFlightId());
        verify(flightRepo, times(1)).save(flightEntity);
    }

    @Test
    void testAddNewFlight_userNotOwner() {
        owner.setUserType(UserType.USER);
        when(userRepo.findById(1)).thenReturn(Optional.of(owner));

        UserNotFoundException ex = assertThrows(UserNotFoundException.class, () -> {
            flightService.AddNewFlight(flightDTO);
        });
        assertTrue(ex.getMessage().toLowerCase().contains("owner"));
    }

    @Test
    void testGetFlightId_success() {
        when(flightRepo.findById(100)).thenReturn(Optional.of(flightEntity));
        when(flightMapper.FlightToDto(flightEntity)).thenReturn(flightDTO);

        FlightDTO result = flightService.getFlightId(100);
        assertEquals(100, result.getFlightId());
    }

    @Test
    void testDeleteFlight_success() {
        when(flightRepo.findById(100)).thenReturn(Optional.of(flightEntity));
        doNothing().when(flightRepo).delete(flightEntity);

        String result = flightService.deleteFlight(100);
        assertEquals("Flight deleted", result);
    }

    @Test
    void testUpdateFlight_success() {
        when(flightRepo.findById(100)).thenReturn(Optional.of(flightEntity));
        when(flightMapper.FlightToDto(any())).thenReturn(flightDTO);

        FlightDTO updated = flightService.updateFlight(100, flightUpdateDTO);
        assertNotNull(updated);
        verify(flightRepo).save(flightEntity);
    }

    @Test
    void testGetOwnedFlights_success() {
        when(userRepo.findById(1)).thenReturn(Optional.of(owner));
        when(flightRepo.findByowner(owner)).thenReturn(List.of(flightEntity));
        when(flightMapper.FlightToDto(flightEntity)).thenReturn(flightDTO);

        List<FlightDTO> result = flightService.getOwnedFlight(1);
        assertEquals(1, result.size());
        assertEquals("Mumbai", result.get(0).getSource());
    }

    @Test
    void testGetFlight_success() {
        SearchFlightDTO sfdto = new SearchFlightDTO();
        sfdto.setDepertureT(LocalDate.now().atStartOfDay());
        sfdto.setSource("Mumbai");
        sfdto.setDestination("Delhi");

        when(flightRepo.findByDepertureTBetweenAndDestinationAndSource(
                any(), any(), eq("Delhi"), eq("Mumbai"))).thenReturn(List.of(flightEntity));

        when(flightMapper.FlightToDto(flightEntity)).thenReturn(flightDTO);

        List<FlightDTO> results = flightService.GetFlight(sfdto);
        assertEquals(1, results.size());
    }

    @Test
    void testGetFlight_noResults() {
        SearchFlightDTO sfdto = new SearchFlightDTO();
        sfdto.setDepertureT(LocalDate.now().atStartOfDay());
        sfdto.setSource("Mumbai");
        sfdto.setDestination("Delhi");

        when(flightRepo.findByDepertureTBetweenAndDestinationAndSource(
                any(), any(), eq("Delhi"), eq("Mumbai"))).thenReturn(Collections.emptyList());

        assertThrows(FlightNotFoundException.class, () -> {
            flightService.GetFlight(sfdto);
        });
    }
}

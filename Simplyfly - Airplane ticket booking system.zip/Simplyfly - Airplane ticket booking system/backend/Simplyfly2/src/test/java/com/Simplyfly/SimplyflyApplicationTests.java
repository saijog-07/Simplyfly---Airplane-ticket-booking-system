package com.Simplyfly;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplyflyApplicationTests {

	@Test
	void contextLoads() {
	}

}

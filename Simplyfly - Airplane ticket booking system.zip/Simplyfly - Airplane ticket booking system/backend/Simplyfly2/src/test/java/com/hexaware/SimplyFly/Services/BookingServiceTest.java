package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.*;
import com.hexaware.SimplyFly.Enums.BookingStatus;
import com.hexaware.SimplyFly.Exceptions.*;
import com.hexaware.SimplyFly.Mappers.BookingMapper;
import com.hexaware.SimplyFly.Models.*;
import com.hexaware.SimplyFly.Repositories.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
public class BookingServiceTest {

    @Mock
    private BookingRepository bookingRepo;
    @Mock
    private UserRepository userRepo;
    @Mock
    private FlightRepository flightRepo;
    @Mock
    private BookingMapper bookingMapper;

    @InjectMocks
    private BookingService bookingService;

    private UserEntity user;
    private FlightEntity flight;
    private BookingEntity bookingEntity;
    private BookingDTO bookingDTO;
    private PaymentDTO paymentDTO;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        user = new UserEntity();
        user.setUserId(1);

        flight = new FlightEntity();
        flight.setFlightId(100);
        flight.setFare(500.0);

        bookingDTO = new BookingDTO();
        bookingDTO.setUserId(1);
        bookingDTO.setFlightId(100);
        bookingDTO.setPassengers(List.of(new PassengerDTO(), new PassengerDTO()));

        paymentDTO = new PaymentDTO();

        bookingEntity = new BookingEntity();
        bookingEntity.setBookingId(999);
        bookingEntity.setFlight(flight);
        bookingEntity.setUser(user);
    }

    @Test
    void testCreateBooking_success() {
        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        when(flightRepo.findById(100)).thenReturn(Optional.of(flight));
        when(bookingMapper.toEntity(any(), any(), any())).thenReturn(bookingEntity);
        when(bookingMapper.toPaymentEntity(any(), any())).thenReturn(new PaymentEntity());
        when(bookingRepo.save(any())).thenReturn(bookingEntity);
        when(bookingMapper.toDTO(any())).thenReturn(bookingDTO);

        BookingDTO result = bookingService.createBooking(bookingDTO, paymentDTO);
        assertEquals(100, result.getFlightId());
        verify(bookingRepo).save(any());
    }

    @Test
    void testCreateBooking_userNotFound() {
        when(userRepo.findById(1)).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, () -> {
            bookingService.createBooking(bookingDTO, paymentDTO);
        });
    }

    @Test
    void testCreateBooking_flightNotFound() {
        when(userRepo.findById(1)).thenReturn(Optional.of(user));
        when(flightRepo.findById(100)).thenReturn(Optional.empty());

        assertThrows(FlightNotFoundException.class, () -> {
            bookingService.createBooking(bookingDTO, paymentDTO);
        });
    }

    @Test
    void testGetBookingsByUserId() {
        when(bookingRepo.findByUserUserId(1)).thenReturn(List.of(bookingEntity));
        when(bookingMapper.toDTO(bookingEntity)).thenReturn(bookingDTO);

        List<BookingDTO> results = bookingService.getBookingsByUserId(1);
        assertEquals(1, results.size());
    }

    @Test
    void testGetBookingById_success() {
        when(bookingRepo.findById(999)).thenReturn(Optional.of(bookingEntity));
        when(bookingMapper.toDTO(bookingEntity)).thenReturn(bookingDTO);

        BookingDTO result = bookingService.getBookingById(999);
        assertEquals(1, result.getUserId());
    }

    @Test
    void testGetBookingById_notFound() {
        when(bookingRepo.findById(999)).thenReturn(Optional.empty());
        assertThrows(BookingNotFoundException.class, () -> {
            bookingService.getBookingById(999);
        });
    }

    @Test
    void testDeleteBookingById_success() {
        when(bookingRepo.existsById(999)).thenReturn(true);
        doNothing().when(bookingRepo).deleteById(999);

        assertDoesNotThrow(() -> bookingService.deleteBookingById(999));
        verify(bookingRepo).deleteById(999);
    }

    @Test
    void testDeleteBookingById_notFound() {
        when(bookingRepo.existsById(999)).thenReturn(false);
        assertThrows(BookingNotFoundException.class, () -> {
            bookingService.deleteBookingById(999);
        });
    }

    @Test
    void testCancelBookingById_success() {
        when(bookingRepo.findById(999)).thenReturn(Optional.of(bookingEntity));
        bookingEntity.setBookingstatus(BookingStatus.BOOKED);

        assertDoesNotThrow(() -> bookingService.cancelBookingById(999));
        verify(bookingRepo).save(bookingEntity);
    }
}

package com.hexaware.SimplyFly.Models;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Owner")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OwnerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String airlineName;

    @Column(length = 10, nullable = false)
    private String licenseNumber;

    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId", nullable = false)
    private UserEntity user;
}

package com.hexaware.SimplyFly.Repositories;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.SimplyFly.Models.FlightEntity;
import com.hexaware.SimplyFly.Models.UserEntity;

public interface FlightRepository extends JpaRepository<FlightEntity, Integer> {

	List<FlightEntity> findByDepertureTAndDestinationAndSource(
			LocalDateTime depertureT,
			String destination,
			String source);

	List<FlightEntity> findByowner(UserEntity owner);

	List<FlightEntity> findByDepertureTBetweenAndDestinationAndSource(
			LocalDateTime departureDate,
			LocalDateTime endOfDay,
			String destination,
			String source);

	List<FlightEntity> findByDestinationIgnoreCase(String destination);

}

package com.hexaware.SimplyFly.DTO;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDate;
import java.util.List;

public class BookingDTO {

    private int bookingId;

    private LocalDate bookingDate = LocalDate.now();

    @NotNull(message = "Flight ID is required")
    private Integer flightId;

    @NotNull(message = "User ID is required")
    private Integer userId;

    private String bookingStatus;

    @Positive(message = "Total fare must be greater than 0")
    private double totalFare;

    private Integer paymentId;

    private List<PassengerDTO> passengers;

    public BookingDTO() {
    }

    public BookingDTO(int bookingId, LocalDate bookingDate, Integer flightId, Integer userId,
                      String bookingStatus, double totalFare, Integer paymentId, List<PassengerDTO> passengers) {
        this.bookingId = bookingId;
        this.bookingDate = bookingDate;
        this.flightId = flightId;
        this.userId = userId;
        this.bookingStatus = bookingStatus;
        this.totalFare = totalFare;
        this.paymentId = paymentId;
        this.passengers = passengers;
    }

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Integer getFlightId() {
		return flightId;
	}

	public void setFlightId(Integer flightId) {
		this.flightId = flightId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getBookingStatus() {
		return bookingStatus;
	}

	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public List<PassengerDTO> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<PassengerDTO> passengers) {
		this.passengers = passengers;
	}

    
}

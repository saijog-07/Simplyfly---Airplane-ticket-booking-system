package com.hexaware.SimplyFly.DTO;

import com.hexaware.SimplyFly.Enums.PaymentType;
import jakarta.validation.constraints.*;

import java.util.Date;

public class PaymentDTO {

    private int paymentId;

    @NotNull(message = "Booking ID is required")
    private Integer bookingId;

    @NotNull(message = "Payment type is required")
    private PaymentType paymentType;

    @NotNull(message = "Payment date is required")
    private Date paymentDate;

    @Positive(message = "Amount must be greater than 0")
    private double amount;

    @NotBlank(message = "Payment status is required")
    private String paymentStatus;

    @NotBlank(message = "Transaction ID is required")
    private String transactionId;

    public PaymentDTO() {
    }

    public PaymentDTO(int paymentId, Integer bookingId, PaymentType paymentType, Date paymentDate,
                      double amount, String paymentStatus, String transactionId) {
        this.paymentId = paymentId;
        this.bookingId = bookingId;
        this.paymentType = paymentType;
        this.paymentDate = paymentDate;
        this.amount = amount;
        this.paymentStatus = paymentStatus;
        this.transactionId = transactionId;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public Integer getBookingId() {
        return bookingId;
    }

    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    @Override
    public String toString() {
        return "PaymentDTO{" +
                "paymentId=" + paymentId +
                ", bookingId=" + bookingId +
                ", paymentType=" + paymentType +
                ", paymentDate=" + paymentDate +
                ", amount=" + amount +
                ", paymentStatus='" + paymentStatus + '\'' +
                ", transactionId='" + transactionId + '\'' +
                '}';
    }
}

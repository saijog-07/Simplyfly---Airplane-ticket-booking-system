package com.hexaware.SimplyFly.Controllers;

import com.hexaware.SimplyFly.DTO.PaymentDTO;
import com.hexaware.SimplyFly.Services.PaymentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/{bookingId}")
    public ResponseEntity<PaymentDTO> getPaymentByBooking(@PathVariable int bookingId) {
        PaymentDTO dto = paymentService.getPaymentByBookingId(bookingId);
        return ResponseEntity.ok(dto);
    }
}

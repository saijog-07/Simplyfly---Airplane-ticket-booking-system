package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.BookingDTO;
import com.hexaware.SimplyFly.DTO.PaymentDTO;
import com.hexaware.SimplyFly.Exceptions.BookingNotFoundException;
import com.hexaware.SimplyFly.Exceptions.FlightNotFoundException;
import com.hexaware.SimplyFly.Exceptions.UserNotFoundException;
import com.hexaware.SimplyFly.Mappers.BookingMapper;
import com.hexaware.SimplyFly.Enums.BookingStatus;
import com.hexaware.SimplyFly.Models.*;
import com.hexaware.SimplyFly.Repositories.*;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private FlightRepository flightRepo;

    @Autowired
    private BookingMapper bookingMapper;

    @Transactional
    public BookingDTO createBooking(BookingDTO bookingDTO, PaymentDTO paymentDTO) {

        UserEntity user = userRepo.findById(bookingDTO.getUserId())
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + bookingDTO.getUserId()));

        FlightEntity flight = flightRepo.findById(bookingDTO.getFlightId())
                .orElseThrow(
                        () -> new FlightNotFoundException("Flight not found with ID: " + bookingDTO.getFlightId()));

        int passengerCount = bookingDTO.getPassengers() != null ? bookingDTO.getPassengers().size() : 0;
        double farePerPassenger = flight.getFare();
        double totalFare = passengerCount * farePerPassenger;

        bookingDTO.setTotalFare(totalFare);
        paymentDTO.setAmount(totalFare);

        BookingEntity booking = bookingMapper.toEntity(bookingDTO, user, flight);
        PaymentEntity payment = bookingMapper.toPaymentEntity(paymentDTO, booking);
        booking.setPayment(payment);

        BookingEntity savedBooking = bookingRepo.save(booking);

        return bookingMapper.toDTO(savedBooking);
    }

    public List<BookingDTO> getBookingsByUserId(int userId) {
        List<BookingEntity> bookings = bookingRepo.findByUserUserId(userId);
        return bookings.stream()
                .map(bookingMapper::toDTO)
                .collect(Collectors.toList());
    }

    public BookingDTO getBookingById(int bookingId) {
        BookingEntity booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with ID: " + bookingId));
        return bookingMapper.toDTO(booking);
    }

    public void deleteBookingById(int bookingId) {
        if (!bookingRepo.existsById(bookingId)) {
            throw new BookingNotFoundException("Booking not found with ID: " + bookingId);
        }
        bookingRepo.deleteById(bookingId);
    }

    public List<BookingDTO> getBookingsByFlightId(int flightId) {
        List<BookingEntity> bookings = bookingRepo.findByFlightFlightId(flightId);
        return bookings.stream()
                .map(bookingMapper::toDTO)
                .collect(Collectors.toList());
    }

    public List<BookingDTO> getBookingsByFlightIdUser(int flightId) {
        List<BookingEntity> bookings = bookingRepo.findByFlight_FlightId(flightId);
        return bookings.stream()
                .map(bookingMapper::toDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public void cancelBookingById(int bookingId) {
        BookingEntity booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with ID: " + bookingId));
        booking.setBookingstatus(BookingStatus.CANCELLED);
        bookingRepo.save(booking);
    }

}

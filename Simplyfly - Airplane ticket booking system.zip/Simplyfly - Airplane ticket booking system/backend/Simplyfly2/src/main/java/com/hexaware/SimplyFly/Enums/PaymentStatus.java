package com.hexaware.SimplyFly.Enums;

public enum PaymentStatus {
	PAID,
    FAILED,
    PENDING,
    REFUNDED
}

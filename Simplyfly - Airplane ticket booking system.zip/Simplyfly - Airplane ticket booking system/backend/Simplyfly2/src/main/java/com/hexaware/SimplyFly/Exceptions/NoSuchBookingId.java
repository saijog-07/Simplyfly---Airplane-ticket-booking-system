package com.hexaware.SimplyFly.Exceptions;

public class NoSuchBookingId extends RuntimeException{

	public NoSuchBookingId(String message) {
		super(message);
	}

}
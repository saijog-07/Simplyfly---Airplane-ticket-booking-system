package com.hexaware.SimplyFly.Exceptions;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ApiError {
    private Instant timestamp = Instant.now();
    
    
    private int status;
    private String error;
    private String message;
    private String path;

}

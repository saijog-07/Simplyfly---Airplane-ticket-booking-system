package com.hexaware.SimplyFly.Services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.SimplyFly.DTO.FlightDTO;
import com.hexaware.SimplyFly.DTO.FlightUpdateDTO;
import com.hexaware.SimplyFly.DTO.SearchFlightDTO;
import com.hexaware.SimplyFly.Enums.UserType;
import com.hexaware.SimplyFly.Exceptions.FlightNotFoundException;
import com.hexaware.SimplyFly.Exceptions.UserNotFoundException;
import com.hexaware.SimplyFly.Mappers.FlightMapper;
import com.hexaware.SimplyFly.Models.FlightEntity;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.FlightRepository;
import com.hexaware.SimplyFly.Repositories.UserRepository;

@Service
public class FlightService {

	@Autowired
	FlightRepository frepo;

	@Autowired
	UserRepository urepo;

	@Autowired
	FlightMapper fmapper;

	public FlightDTO AddNewFlight(FlightDTO fdto) {
		FlightEntity fentity = fmapper.DtoToFlight(fdto);
		int ownerid = fdto.getOwnerId();
		UserEntity uentity = urepo.findById(ownerid)
				.orElseThrow(() -> new UserNotFoundException("User with ID " + ownerid + " not found"));

		if (uentity.getUserType() != UserType.OWNER) {
			throw new UserNotFoundException("User of owner id should be owner");
		}

		FlightEntity f1entity = frepo.save(fentity);
		return fmapper.FlightToDto(f1entity);
	}

	public List<FlightDTO> GetFlight(SearchFlightDTO sFDto) {
		LocalDateTime departureDate = sFDto.getDepertureT().toLocalDate().atStartOfDay();
		LocalDateTime endOfDay = departureDate.plusDays(1).minusNanos(1);

		String destination = sFDto.getDestination();
		String source = sFDto.getSource();

		List<FlightEntity> flights = frepo.findByDepertureTBetweenAndDestinationAndSource(
				departureDate, endOfDay, destination, source);

		if (flights.isEmpty()) {
			throw new FlightNotFoundException("Flight for above not found");
		}

		return flights.stream()
				.map(fmapper::FlightToDto)
				.collect(Collectors.toList());
	}

	public FlightDTO getFlightId(int id) {
		FlightEntity fentity = frepo.findById(id)
				.orElseThrow(() -> new FlightNotFoundException("Flight with id " + id + " not found"));
		return fmapper.FlightToDto(fentity);
	}

	public FlightDTO updateFlight(int id, FlightUpdateDTO dto) {
		FlightEntity fentity = frepo.findById(id)
				.orElseThrow(() -> new FlightNotFoundException("Flight with id " + id + " not found"));

		if (dto.getArrivalT() != null)
			fentity.setArrivalT(dto.getArrivalT());

		if (dto.getAvailSeats() != null)
			fentity.setAvailSeats(dto.getAvailSeats());

		if (dto.getBaggage() != null && !dto.getBaggage().trim().isEmpty())
			fentity.setBaggage(dto.getBaggage().trim());

		if (dto.getDepertureT() != null)
			fentity.setDepertureT(dto.getDepertureT());

		if (dto.getDestination() != null && !dto.getDestination().trim().isEmpty())
			fentity.setDestination(dto.getDestination().trim());

		if (dto.getFare() != null)
			fentity.setFare(dto.getFare());

		if (dto.getSource() != null && !dto.getSource().trim().isEmpty())
			fentity.setSource(dto.getSource().trim());

		if (dto.getTotalSeats() != null)
			fentity.setTotalSeats(dto.getTotalSeats());

		frepo.save(fentity);
		return fmapper.FlightToDto(fentity);
	}

	public String deleteFlight(int id) {
		FlightEntity fentity = frepo.findById(id)
				.orElseThrow(() -> new FlightNotFoundException("Flight with id " + id + " not found"));

		frepo.delete(fentity);
		return "Flight deleted";
	}

	public List<FlightDTO> getOwnedFlight(int ownerid) {
		UserEntity owner = urepo.findById(ownerid)
				.orElseThrow(() -> new UserNotFoundException("Owner not found"));

		List<FlightEntity> fentitylist = frepo.findByowner(owner);

		if (fentitylist.isEmpty()) {
			throw new FlightNotFoundException("Flight for owner id " + ownerid + " not found");
		}

		return fentitylist.stream()
				.map(fmapper::FlightToDto)
				.collect(Collectors.toList());
	}

	public List<FlightDTO> getFlightsByDestination(String destination) {
		List<FlightEntity> flights = frepo.findByDestinationIgnoreCase(destination);
		return flights.stream()
				.map(fmapper::FlightToDto)
				.collect(Collectors.toList());
	}

	public List<FlightDTO> getAllFlights() {
		List<FlightEntity> flights = frepo.findAll();
		return flights.stream()
				.map(fmapper::FlightToDto)
				.collect(Collectors.toList());
	}

	public List<FlightDTO> getAll() {
		List<FlightEntity> fentityl = frepo.findAll();
		List<FlightDTO> flightsDto = fentityl.stream()
				.map(fmapper::FlightToDto)
				.collect(Collectors.toList());
		return flightsDto;
	}
}

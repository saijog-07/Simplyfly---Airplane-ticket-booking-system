package com.hexaware.SimplyFly.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.SimplyFly.DTO.AdminDTO;
import com.hexaware.SimplyFly.DTO.AdminProfileDTO;
import com.hexaware.SimplyFly.Models.AdminEntity;
import com.hexaware.SimplyFly.Models.OwnerEntity;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.AdminRepository;
import com.hexaware.SimplyFly.Repositories.UserRepository;

@Service
public class AdminService {
    @Autowired
    AdminRepository arepo;

    @Autowired
    UserRepository urepo;

    public AdminEntity registerAdmin(AdminDTO dto) throws Exception {
        UserEntity user = urepo.findById(dto.getUserId())
                .orElseThrow(() -> new Exception("User not found with id " + dto.getUserId()));

        AdminEntity admin = new AdminEntity();
        admin.setUniqueId(dto.getUniqueId());
        admin.setUser(user);

        return arepo.save(admin);
    }

    public AdminProfileDTO getAdmin(int userId) throws Exception {
        UserEntity user = urepo.findById(userId)
                .orElseThrow(() -> new Exception("User not found with id " + userId));

        AdminEntity admin = arepo.findByUserUserId(userId)
                .orElseThrow(() -> new Exception("User not found with id " + userId));

        AdminProfileDTO adto = new AdminProfileDTO();
        adto.setUserName(user.getUserName());
        adto.setUserEmail(user.getUserEmail());
        adto.setUserContact(user.getUserContact());
        adto.setUserId(user.getUserId());
        adto.setUniqueId(admin.getUniqueId());

        return adto;
    }

}
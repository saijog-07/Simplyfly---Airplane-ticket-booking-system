package com.hexaware.SimplyFly.Enums;

public enum UserType {
	ADMIN,
	OWNER,
	USER
}
// PaymentRepository.java
package com.hexaware.SimplyFly.Repositories;

import com.hexaware.SimplyFly.Models.BookingEntity;
import com.hexaware.SimplyFly.Models.PaymentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PaymentRepository extends JpaRepository<PaymentEntity, Integer> {
    Optional<PaymentEntity> findByBooking(BookingEntity booking);
}

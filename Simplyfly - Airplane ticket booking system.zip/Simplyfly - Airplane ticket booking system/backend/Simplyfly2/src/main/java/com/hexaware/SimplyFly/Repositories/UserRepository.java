package com.hexaware.SimplyFly.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hexaware.SimplyFly.Models.UserEntity;
import java.util.List;

public interface UserRepository extends JpaRepository<UserEntity, Integer> {

	public UserEntity findByuserEmail(String email);

	@Query("SELECT u FROM UserEntity u WHERE u.userType = 'OWNER'")
	List<UserEntity> findAllOwner();
}

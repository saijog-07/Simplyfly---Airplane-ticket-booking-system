package com.hexaware.SimplyFly.Mappers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.SimplyFly.DTO.UserDTO;
import com.hexaware.SimplyFly.Models.UserEntity;

@Component
public class UserMapper {
	
	@Autowired
	ModelMapper modelMapper;
	
	public UserEntity DtoToUser(UserDTO udto) {
		UserEntity uEntity = modelMapper.map(udto, UserEntity.class);
		
		return uEntity;
	}
	
	public UserDTO UserToDto(UserEntity uEntity) {
		UserDTO udto = modelMapper.map(uEntity, UserDTO.class);
		
		return udto;
	}

}
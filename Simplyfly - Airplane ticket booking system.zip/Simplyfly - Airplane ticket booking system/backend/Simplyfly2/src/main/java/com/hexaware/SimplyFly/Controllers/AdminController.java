package com.hexaware.SimplyFly.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.SimplyFly.DTO.AdminDTO;
import com.hexaware.SimplyFly.DTO.AdminProfileDTO;
import com.hexaware.SimplyFly.Models.AdminEntity;
import com.hexaware.SimplyFly.Models.OwnerEntity;
import com.hexaware.SimplyFly.Services.AdminService;

@RestController
@RequestMapping("/api")
public class AdminController {

    @Autowired
    AdminService aservice;

    @PostMapping("auth/admin-register")
    public ResponseEntity<?> registerAdmin(@RequestBody AdminDTO dto) {
        try {
            AdminEntity savedAdmin = aservice.registerAdmin(dto);
            return ResponseEntity.ok(savedAdmin);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @GetMapping("user/getAdmin/{userId}")
    public ResponseEntity<?> getAdminProfile(@PathVariable int userId) {
        try {
            AdminProfileDTO admin = aservice.getAdmin(userId);
            return ResponseEntity.ok(admin);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
}
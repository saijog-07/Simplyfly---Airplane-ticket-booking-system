package com.hexaware.SimplyFly.Mappers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.hexaware.SimplyFly.DTO.PaymentDTO;
import com.hexaware.SimplyFly.Models.PaymentEntity;
import org.springframework.stereotype.Component;

@Component
public class PaymentMapper {

	@Autowired
	ModelMapper modelMapper;
	
	public PaymentEntity DtoToPayment(PaymentDTO pDTO) {
		PaymentEntity pEntity = modelMapper.map(pDTO, PaymentEntity.class);
		return pEntity;
	}
	
	public PaymentDTO PaymentToDto(PaymentEntity pEntity) {
		PaymentDTO pDTO = modelMapper.map(pEntity, PaymentDTO.class);
		return pDTO;
	}
}

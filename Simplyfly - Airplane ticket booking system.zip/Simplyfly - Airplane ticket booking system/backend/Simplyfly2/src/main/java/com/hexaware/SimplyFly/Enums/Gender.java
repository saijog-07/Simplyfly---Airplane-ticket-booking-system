package com.hexaware.SimplyFly.Enums;

public enum Gender {
	MALE,
	FEMALE
}
package com.hexaware.SimplyFly.DTO;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class AdminDTO {

    @NotBlank(message = "Airline name is required")
    @Pattern(regexp = "\\d{10}", message = "License number must be exactly 10 digits")
    private String uniqueId;

    @Min(value = 1, message = "User ID must be a positive number")
    private int userId;
}
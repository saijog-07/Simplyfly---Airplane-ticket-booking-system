package com.hexaware.SimplyFly.Controllers;

import com.hexaware.SimplyFly.DTO.PassengerDTO;
import com.hexaware.SimplyFly.Services.PassengerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin
public class PassengerController {

    @Autowired
    private PassengerService passengerService;

    @GetMapping("/{id}/passengers")
    public ResponseEntity<List<PassengerDTO>> getPassengers(@PathVariable int id) {
        List<PassengerDTO> passengers = passengerService.getPassengersByBookingId(id);
        return ResponseEntity.ok(passengers);
    }

    @GetMapping("/flights/{flightId}/booked-seats")
    public ResponseEntity<List<String>> getBookedSeats(@PathVariable Long flightId) {
        List<String> seatNumbers = passengerService.getBookedSeatsForFlight(flightId);
        return ResponseEntity.ok(seatNumbers);
    }

}

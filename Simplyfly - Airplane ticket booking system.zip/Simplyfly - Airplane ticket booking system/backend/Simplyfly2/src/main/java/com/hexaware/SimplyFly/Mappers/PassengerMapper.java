package com.hexaware.SimplyFly.Mappers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.SimplyFly.DTO.PassengerDTO;
import com.hexaware.SimplyFly.Models.PassengerEntity;

@Component
public class PassengerMapper {

	@Autowired
	ModelMapper modelMapper;
	
	public PassengerEntity DtoToPassenger(PassengerDTO dto) {
		PassengerEntity entity = new PassengerEntity();
		entity.setPassengerName(dto.getPassengerName());
		entity.setPassengerAge(dto.getPassengerAge());
		entity.setPassengerGender(dto.getPassengerGender());
		entity.setSeatNo(dto.getSeatNo());
		return entity;
	}

	public PassengerDTO PassengerToDto(PassengerEntity entity) {
		PassengerDTO dto = new PassengerDTO();
		dto.setPasssengerId(entity.getPasssengerId());
		dto.setPassengerName(entity.getPassengerName());
		dto.setPassengerAge(entity.getPassengerAge());
		dto.setPassengerGender(entity.getPassengerGender());
		dto.setSeatNo(entity.getSeatNo());
		dto.setBookingId(entity.getBooking().getBookingId());
		return dto;
	}
}
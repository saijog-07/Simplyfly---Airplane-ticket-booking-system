package com.hexaware.SimplyFly.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import com.hexaware.SimplyFly.DTO.ForgotPasswordDTO;
import com.hexaware.SimplyFly.DTO.LoginDTO;
import com.hexaware.SimplyFly.DTO.UserDTO;
import com.hexaware.SimplyFly.DTO.UserUpdateDTO;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Services.UserDetailsServiceImpl;
import com.hexaware.SimplyFly.Services.UserService;
import com.hexaware.SimplyFly.Utils.JwtUtil;

import jakarta.validation.Valid;

import java.util.*;

@RestController
@RequestMapping("/api")
public class UserController {

    @Autowired
    private UserService userservice;

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/auth/register")
    public ResponseEntity<UserDTO> registerUser(@RequestBody @Valid UserDTO udto) {
        UserDTO u1dto = userservice.RegisterUserService(udto);
        HttpHeaders header = new HttpHeaders();
        header.add("header-Info", "User Created Successfully.");
        return new ResponseEntity<>(u1dto, header, HttpStatus.CREATED);
    }

    @PostMapping("/auth/login")
    public ResponseEntity<String> login(@RequestBody @Valid LoginDTO ldto) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(ldto.getUserEmail(), ldto.getUserPassword()));

            UserEntity user = userservice.getUserByEmail(ldto.getUserEmail());
            if (user == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
            }

            String token = jwtUtil.generateToken(user);

            return ResponseEntity.ok(token);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Login failed: " + e.getMessage());
        }
    }

    @GetMapping("/user/profile/{userId}")
    public ResponseEntity<UserDTO> getProfileInfo(@PathVariable int userId) {
        UserDTO u1dto = userservice.GetProfileService(userId);
        HttpHeaders header = new HttpHeaders();
        if (u1dto != null) {
            header.add("header-Info", "User Details Retrieved Successfully.");
            return new ResponseEntity<>(u1dto, header, HttpStatus.OK);
        }
        header.add("header-Info", "User Not Found.");
        return new ResponseEntity<>(null, header, HttpStatus.NOT_FOUND);
    }

    @PutMapping("/user/profile/{userId}")
    public ResponseEntity<UserDTO> updateProfileInfo(
            @PathVariable int userId,
            @RequestBody @Valid UserUpdateDTO updateDTO) {

        UserDTO updatedUser = userservice.updateProfileFields(userId, updateDTO);
        HttpHeaders header = new HttpHeaders();

        if (updatedUser != null) {
            header.add("header-Info", "User Profile Updated Successfully.");
            return new ResponseEntity<>(updatedUser, header, HttpStatus.OK);
        }

        header.add("header-Info", "User Not Found");
        return new ResponseEntity<>(null, header, HttpStatus.NOT_FOUND);
    }

    @PutMapping("/auth/forgotpwd")
    public ResponseEntity<UserDTO> forgotPassword(@RequestBody @Valid ForgotPasswordDTO dto) {
        UserDTO updated = userservice.forgotPasswordService(dto);
        HttpHeaders header = new HttpHeaders();

        if (updated != null) {
            header.add("header-Info", "Password Updated Successfully.");
            return new ResponseEntity<>(updated, header, HttpStatus.OK);
        }

        header.add("header-Info", "User Not Found");
        return new ResponseEntity<>(null, header, HttpStatus.NOT_FOUND);
    }

    @GetMapping("/admin/getusers")
    public ResponseEntity<List<UserDTO>> getAllUsers() {
        List<UserDTO> users = userservice.getAllUsers();
        HttpHeaders header = new HttpHeaders();
        header.add("header-Info", "All users fetched successfully.");
        return new ResponseEntity<>(users, header, HttpStatus.OK);
    }

    @GetMapping("/admin/getOwners")
    public ResponseEntity<?> getAllOwners() {
        List<Map<String, Object>> owners = userservice.getAllOwners();

        if (owners.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No owners found");
        }

        return ResponseEntity.ok(owners);
    }

}

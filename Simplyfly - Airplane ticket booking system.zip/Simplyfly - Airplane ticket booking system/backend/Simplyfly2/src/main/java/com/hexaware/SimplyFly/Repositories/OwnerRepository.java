package com.hexaware.SimplyFly.Repositories;

import com.hexaware.SimplyFly.Models.OwnerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.*;

public interface OwnerRepository extends JpaRepository<OwnerEntity, Integer> {
    OwnerEntity findByUser_UserId(int userId);

    Optional<OwnerEntity> findByUserUserId(int userId);

    @Query("SELECT o FROM OwnerEntity o JOIN FETCH o.user")
    List<OwnerEntity> findAllOwners();

}

package com.hexaware.SimplyFly.DTO;

import com.hexaware.SimplyFly.Enums.Gender;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PassengerDTO {

     private int passsengerId;
     @NotBlank(message = "Passenger name is required")
     @Size(min = 2, max = 50, message = "Passenger name must be between 2 and 50 characters")
     private String passengerName;
     @Min(value = 2)
     private int passengerAge;
     @NotNull(message = "Gender is required")

     private Gender passengerGender;
     @NotNull(message = "seatno should not be empty")
     private String seatNo;

     @NotNull(message = "Booking ID is required")
     private int bookingId;
}
package com.hexaware.SimplyFly.Controllers;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.SimplyFly.DTO.FlightDTO;
import com.hexaware.SimplyFly.DTO.FlightUpdateDTO;
import com.hexaware.SimplyFly.DTO.SearchFlightDTO;
import com.hexaware.SimplyFly.Services.FlightService;
import org.springframework.web.bind.annotation.RequestBody;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class FlightController {

	@Autowired
	FlightService flightservice;

	@PostMapping("/flights/addFlight")
	public ResponseEntity<FlightDTO> AddFlight(@RequestBody @Valid FlightDTO fdto) {
		FlightDTO f1dto = flightservice.AddNewFlight(fdto);
		HttpHeaders header = new HttpHeaders();
		header.add("Header Info", "New Flight Added");
		return new ResponseEntity<>(f1dto, header, HttpStatus.CREATED);
	}

	@PostMapping("/flights/search")
	public ResponseEntity<List<FlightDTO>> SearchFlight(@RequestBody SearchFlightDTO sFDto) {

		List<FlightDTO> fdto = flightservice.GetFlight(sFDto);
		HttpHeaders header = new HttpHeaders();
		if (fdto != null) {
			header.add("Header info", "Flight detail");
			return new ResponseEntity<>(fdto, header, HttpStatus.OK);
		}
		header.add("Header info", "Flight detail not found");
		return new ResponseEntity<>(null, header, HttpStatus.NOT_FOUND);

	}

	@GetMapping("/flights/{id}")
	public ResponseEntity<FlightDTO> GetFlightId(@PathVariable int id) {

		FlightDTO fdto = flightservice.getFlightId(id);
		HttpHeaders header = new HttpHeaders();
		if (fdto != null) {
			header.add("Header info", "Flight found");
			return new ResponseEntity<>(fdto, header, HttpStatus.OK);

		}
		header.add("Header info", "Flight detail not found");
		return new ResponseEntity<>(null, header, HttpStatus.NOT_FOUND);
	}

	@PutMapping("/owner/flights/{id}")
	public ResponseEntity<FlightDTO> updateFlight(
			@PathVariable int id,
			@RequestBody @Valid FlightUpdateDTO updateDTO) {

		FlightDTO updated = flightservice.updateFlight(id, updateDTO);
		return ResponseEntity.ok(updated);
	}

	@DeleteMapping("/owner/flights/{id}")
	public ResponseEntity<String> DeleteFlight(@PathVariable int id) {

		String fdto = flightservice.deleteFlight(id);
		HttpHeaders header = new HttpHeaders();
		if (fdto != null) {
			header.add("Header info", "Flight Updated");
			return new ResponseEntity<>(fdto, header, HttpStatus.OK);
		}
		header.add("Header info", "Flight detail not found");
		return new ResponseEntity<>(fdto, header, HttpStatus.NOT_FOUND);
	}

	@GetMapping("/owner/flights/{ownerid}")
	public ResponseEntity<List<FlightDTO>> OwnedFlight(@PathVariable int ownerid) {

		List<FlightDTO> fdto = flightservice.getOwnedFlight(ownerid);
		HttpHeaders header = new HttpHeaders();
		if (fdto != null) {
			header.add("Header info", "Flight detail");
			return new ResponseEntity<>(fdto, header, HttpStatus.OK);
		}
		header.add("Header info", "Flight detail not found");
		return new ResponseEntity<>(null, header, HttpStatus.NOT_FOUND);

	}

	@GetMapping("/flights/destination/{destination}")
	public ResponseEntity<List<FlightDTO>> getFlightsByDestination(@PathVariable String destination) {
		List<FlightDTO> flights = flightservice.getFlightsByDestination(destination);
		HttpHeaders headers = new HttpHeaders();

		if (flights != null && !flights.isEmpty()) {
			headers.add("Header info", "Flights to destination found");
			return new ResponseEntity<>(flights, headers, HttpStatus.OK);
		}

		headers.add("Header info", "No flights found for destination");
		return new ResponseEntity<>(null, headers, HttpStatus.NOT_FOUND);
	}

	@GetMapping("/flights")
	public ResponseEntity<List<FlightDTO>> getAllFlights() {
		List<FlightDTO> allFlights = flightservice.getAllFlights();
		return allFlights.isEmpty()
				? ResponseEntity.noContent().build()
				: ResponseEntity.ok(allFlights);
	}

	@GetMapping("/getAllFlight")
	public ResponseEntity<List<FlightDTO>> GetAllFlights() {
		List<FlightDTO> flist = flightservice.getAll();
		HttpHeaders headers = new HttpHeaders();
		if (flist.isEmpty()) {
			headers.add("Header info", "Flights are not available");
			return new ResponseEntity<>(null, headers, HttpStatus.NOT_FOUND);
		}
		headers.add("Header info", "Flight found");
		return new ResponseEntity<>(flist, headers, HttpStatus.OK);
	}

}
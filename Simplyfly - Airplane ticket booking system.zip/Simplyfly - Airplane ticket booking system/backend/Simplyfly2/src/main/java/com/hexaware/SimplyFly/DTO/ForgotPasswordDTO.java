package com.hexaware.SimplyFly.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString


public class ForgotPasswordDTO {

	@NotBlank(message = "Email is required")
    @Email(message = "Enter a valid email")
    private String userEmail;

    @NotBlank(message = "User name is required")
    private String userName;

    @NotBlank(message = "Password is required")
    @Size(min = 8, message = "Password should be at least 8 characters long")
    private String userPwd;

}

package com.hexaware.SimplyFly.DTO;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class SearchFlightDTO {

	private LocalDateTime depertureT;

	@NotBlank(message = "Destination is required")
	private String destination;

	@NotBlank(message = "Source is required")
	private String source;

}
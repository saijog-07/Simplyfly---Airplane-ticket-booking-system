package com.hexaware.SimplyFly.Controllers;

import com.hexaware.SimplyFly.DTO.OwnerDTO;
import com.hexaware.SimplyFly.DTO.OwnerProfileDTO;
import com.hexaware.SimplyFly.Models.OwnerEntity;
import com.hexaware.SimplyFly.Services.OwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class OwnerController {

    @Autowired
    private OwnerService ownerService;

    @PostMapping("auth/register-owner")
    public ResponseEntity<?> registerOwner(@RequestBody OwnerDTO dto) {
        try {
            OwnerEntity savedOwner = ownerService.registerOwner(dto);
            return ResponseEntity.ok(savedOwner);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @GetMapping("user/owner-profile/{userId}")
    public ResponseEntity<?> getOwnerProfile(@PathVariable int userId) {
        try {
            OwnerProfileDTO profile = ownerService.getOwnerProfile(userId);
            return ResponseEntity.ok(profile);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

}

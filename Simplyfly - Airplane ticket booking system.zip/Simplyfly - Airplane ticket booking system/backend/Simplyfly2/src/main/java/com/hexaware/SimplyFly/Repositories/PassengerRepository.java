// PassengerRepository.java
package com.hexaware.SimplyFly.Repositories;

import com.hexaware.SimplyFly.Models.BookingEntity;
import com.hexaware.SimplyFly.Models.PassengerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PassengerRepository extends JpaRepository<PassengerEntity, Integer> {
    List<PassengerEntity> findByBooking(BookingEntity booking);

    @Query("SELECT p.seatNo FROM PassengerEntity p WHERE p.booking.flight.flightId = :flightId AND p.booking.Bookingstatus = BookingStatus.BOOKED")
    List<String> findBookedSeatsByFlightIdWithBookedStatus(@Param("flightId") Long flightId);

}

package com.hexaware.SimplyFly.Models;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.hexaware.SimplyFly.Enums.Gender;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

@Entity
@Table(name = "Passenger")
public class PassengerEntity {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int passsengerId;

        private String passengerName;

        private int passengerAge;

        @Enumerated(EnumType.STRING)
        private Gender passengerGender;

        private String seatNo;
        @ManyToOne
        @JoinColumn(name = "booking_id", nullable = false)
        @JsonBackReference
        private BookingEntity booking;

}
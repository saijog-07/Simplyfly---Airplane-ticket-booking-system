package com.hexaware.SimplyFly.DTO;

import lombok.Data;

@Data
public class AdminProfileDTO {

    private int userId;
    private String userName;
    private String userEmail;
    private long userContact;
    private String uniqueId;

}
package com.hexaware.SimplyFly.Repositories;

import com.hexaware.SimplyFly.Models.BookingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingRepository extends JpaRepository<BookingEntity, Integer> {
    List<BookingEntity> findByUserUserId(int userId);

    List<BookingEntity> findByFlightFlightId(int flightId);

    List<BookingEntity> findByFlight_FlightId(int flightId);

}

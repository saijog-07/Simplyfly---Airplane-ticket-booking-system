package com.hexaware.SimplyFly.Mappers;

import com.hexaware.SimplyFly.DTO.*;
import com.hexaware.SimplyFly.Enums.BookingStatus;
import com.hexaware.SimplyFly.Models.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;
import java.util.Date;


@Component
public class BookingMapper {

    public BookingEntity toEntity(BookingDTO dto, UserEntity user, FlightEntity flight) {
        BookingEntity booking = new BookingEntity();
        booking.setBookingDate(dto.getBookingDate());
        booking.setTotalFare(dto.getTotalFare());
        booking.setBookingstatus(BookingStatus.valueOf(dto.getBookingStatus()));
        booking.setUser(user);
        booking.setFlight(flight);

        if (dto.getPassengers() != null) {
            List<PassengerEntity> passengers = dto.getPassengers().stream().map(pdto -> {
                PassengerEntity p = new PassengerEntity();
                p.setPassengerName(pdto.getPassengerName());
                p.setPassengerAge(pdto.getPassengerAge());
                p.setPassengerGender(pdto.getPassengerGender());
                p.setSeatNo(pdto.getSeatNo());
                p.setBooking(booking); 
                return p;
            }).collect(Collectors.toList());

            booking.setPassengers(passengers);
        }

        return booking;
    }

    public PaymentEntity toPaymentEntity(PaymentDTO dto, BookingEntity booking) {
        PaymentEntity payment = new PaymentEntity();
        payment.setPaymentDate(new Date());
        payment.setAmount(dto.getAmount());
        payment.setPaymentType(dto.getPaymentType());
        payment.setPaymentStatus(dto.getPaymentStatus());
        payment.setTransactionId(dto.getTransactionId());
        payment.setBooking(booking); 
        return payment;
    }

    public BookingDTO toDTO(BookingEntity entity) {
        BookingDTO dto = new BookingDTO();

        dto.setBookingId(entity.getBookingId());
        dto.setBookingDate(entity.getBookingDate());
        dto.setFlightId(entity.getFlight().getFlightId());
        dto.setUserId(entity.getUser().getUserId());
        dto.setBookingStatus(entity.getBookingstatus().toString());
        dto.setTotalFare(entity.getTotalFare());
        
        if (entity.getPayment() != null) {
            dto.setPaymentId(entity.getPayment().getPaymentId());
        }

        if (entity.getPassengers() != null) {
            List<PassengerDTO> passengers = entity.getPassengers().stream().map(p -> {
                PassengerDTO pdto = new PassengerDTO();
                pdto.setPasssengerId(p.getPasssengerId());
                pdto.setPassengerName(p.getPassengerName());
                pdto.setPassengerAge(p.getPassengerAge());
                pdto.setPassengerGender(p.getPassengerGender());
                pdto.setSeatNo(p.getSeatNo());
                pdto.setBookingId(entity.getBookingId());
                return pdto;
            }).collect(Collectors.toList());

            dto.setPassengers(passengers);
        }

        return dto;
    }

}

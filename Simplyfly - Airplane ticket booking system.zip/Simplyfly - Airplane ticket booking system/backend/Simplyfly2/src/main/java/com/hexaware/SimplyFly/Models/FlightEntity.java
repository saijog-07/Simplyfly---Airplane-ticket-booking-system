package com.hexaware.SimplyFly.Models;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "Flight")
public class FlightEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int flightId;

    private String flightNumber;

    private String airlineName;

    @ManyToOne
    @JoinColumn(name = "ownerId", referencedColumnName = "userId")
    private UserEntity owner;

    private int availSeats;

    private int totalSeats;

    private String baggage;

    private LocalDateTime depertureT;

    private LocalDateTime arrivalT;

    private double fare;

    private String destination;

    private String source;
}
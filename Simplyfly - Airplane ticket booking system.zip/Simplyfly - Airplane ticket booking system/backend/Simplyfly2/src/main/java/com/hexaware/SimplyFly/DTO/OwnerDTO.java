package com.hexaware.SimplyFly.DTO;

import jakarta.validation.constraints.*;

import lombok.Data;

@Data
public class OwnerDTO {

    @NotBlank(message = "Airline name is required")
    private String airlineName;

    @NotBlank(message = "License number is required")
    @Pattern(regexp = "\\d{10}", message = "License number must be exactly 10 digits")
    private String licenseNumber;

    @Min(value = 1, message = "User ID must be a positive number")
    private int userId;
}

package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.PassengerDTO;
import com.hexaware.SimplyFly.Exceptions.BookingNotFoundException;
import com.hexaware.SimplyFly.Models.BookingEntity;
import com.hexaware.SimplyFly.Models.PassengerEntity;
import com.hexaware.SimplyFly.Repositories.BookingRepository;
import com.hexaware.SimplyFly.Repositories.PassengerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PassengerService {

    @Autowired
    private PassengerRepository passengerRepo;

    @Autowired
    private BookingRepository bookingRepo;

    public List<PassengerDTO> getPassengersByBookingId(int bookingId) {
        BookingEntity booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with ID: " + bookingId));

        List<PassengerEntity> passengerEntities = passengerRepo.findByBooking(booking);

        return passengerEntities.stream().map(p -> {
            PassengerDTO dto = new PassengerDTO();
            dto.setPasssengerId(p.getPasssengerId());
            dto.setPassengerName(p.getPassengerName());
            dto.setPassengerAge(p.getPassengerAge());
            dto.setPassengerGender(p.getPassengerGender());
            dto.setSeatNo(p.getSeatNo());
            dto.setBookingId(bookingId);
            return dto;
        }).collect(Collectors.toList());
    }

    public List<String> getBookedSeatsForFlight(Long flightId) {
        return passengerRepo.findBookedSeatsByFlightIdWithBookedStatus(flightId);
    }
}

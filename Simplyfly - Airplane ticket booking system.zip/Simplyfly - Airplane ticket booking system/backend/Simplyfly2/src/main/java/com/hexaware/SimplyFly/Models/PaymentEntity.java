package com.hexaware.SimplyFly.Models;

import com.hexaware.SimplyFly.Enums.PaymentType;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name="Payment")
public class PaymentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int paymentId;

    @OneToOne
    @JoinColumn(name = "booking_id", referencedColumnName = "bookingId")
    private BookingEntity booking;

    @Enumerated(EnumType.STRING)
    private PaymentType paymentType;

    private Date paymentDate;

    private double amount;

    private String paymentStatus;

    private String transactionId;

    public PaymentEntity() {
    }

    public PaymentEntity(int paymentId, BookingEntity booking, PaymentType paymentType, Date paymentDate,
                         double amount, String paymentStatus, String transactionId) {
        this.paymentId = paymentId;
        this.booking = booking;
        this.paymentType = paymentType;
        this.paymentDate = paymentDate;
        this.amount = amount;
        this.paymentStatus = paymentStatus;
        this.transactionId = transactionId;
    }

    public int getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(int paymentId) {
        this.paymentId = paymentId;
    }

    public BookingEntity getBooking() {
        return booking;
    }

    public void setBooking(BookingEntity booking) {
        this.booking = booking;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    @Override
    public String toString() {
        return "PaymentEntity{" +
                "paymentId=" + paymentId +
                ", booking=" + (booking != null ? booking.getBookingId() : null) +
                ", paymentType=" + paymentType +
                ", paymentDate=" + paymentDate +
                ", amount=" + amount +
                ", paymentStatus='" + paymentStatus + '\'' +
                ", transactionId='" + transactionId + '\'' +
                '}';
    }
}

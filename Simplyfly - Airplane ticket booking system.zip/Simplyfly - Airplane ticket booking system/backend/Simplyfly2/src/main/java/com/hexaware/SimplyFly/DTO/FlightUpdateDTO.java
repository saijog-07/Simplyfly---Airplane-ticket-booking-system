package com.hexaware.SimplyFly.DTO;

import java.time.LocalDateTime;
import jakarta.validation.constraints.Min;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FlightUpdateDTO {

    @Min(value = 0, message = "Available seats cannot be negative")
    private Integer availSeats;

    @Min(value = 1, message = "Total seats must be at least 1")
    private Integer totalSeats;

    private String baggage;

    private LocalDateTime depertureT;
    private LocalDateTime arrivalT;

    @Min(value = 0, message = "Fare cannot be negative")
    private Double fare;

    private String destination;
    private String source;
}

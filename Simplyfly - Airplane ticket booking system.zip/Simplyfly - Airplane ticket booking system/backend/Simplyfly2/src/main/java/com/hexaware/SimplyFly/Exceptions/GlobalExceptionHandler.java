package com.hexaware.SimplyFly.Exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;



import jakarta.servlet.http.HttpServletRequest;



@RestControllerAdvice
public class GlobalExceptionHandler {
          
	 @ExceptionHandler(UserNotFoundException.class)
	 public ResponseEntity<ApiError> handleAlreadyExists(
	           UserNotFoundException ex, HttpServletRequest req) {
	        return buildError(ex, req, HttpStatus.CONFLICT);
	    }
	 
	 @ExceptionHandler(FlightNotFoundException.class) 
	 public ResponseEntity<ApiError> flightNotFound(
			 FlightNotFoundException ex, HttpServletRequest req) {
		 return buildError(ex, req, HttpStatus.CONFLICT);
	 }
	 
	 @ExceptionHandler(NoSuchBookingId.class)
	 public ResponseEntity<ApiError> handleNoSuchBookingId(
			 NoSuchBookingId ex,HttpServletRequest req) {
		 return buildError(ex, req,HttpStatus.CONFLICT);
	 }
	 
	 @ExceptionHandler(BookingNotFoundException.class)
	 public ResponseEntity<ApiError> bookingNotFound(
			 BookingNotFoundException ex,HttpServletRequest req) {
		 return buildError(ex, req,HttpStatus.CONFLICT);
	 }
	 
	 @ExceptionHandler(PaymentNotFoundException.class)
	 public ResponseEntity<ApiError> PaymentNotFound(
			 PaymentNotFoundException ex,HttpServletRequest req) {
		 return buildError(ex, req,HttpStatus.CONFLICT);
	 }
	 
	 private ResponseEntity<ApiError> buildError(
			 Exception ex, HttpServletRequest req, HttpStatus status) {
	        ApiError err = new ApiError();
	        err.setStatus(status.value());
	        err.setError(status.getReasonPhrase());
	        err.setMessage(ex.getMessage());
	        err.setPath(req.getRequestURI());
	        return new ResponseEntity<>(err, status);
	    }
}

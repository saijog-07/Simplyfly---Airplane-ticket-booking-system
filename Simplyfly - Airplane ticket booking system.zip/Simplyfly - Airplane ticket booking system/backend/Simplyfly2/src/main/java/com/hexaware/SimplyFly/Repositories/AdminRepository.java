package com.hexaware.SimplyFly.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hexaware.SimplyFly.Models.AdminEntity;
import com.hexaware.SimplyFly.Models.UserEntity;

@Repository
public interface AdminRepository extends JpaRepository<AdminEntity, Integer> {

    Optional<AdminEntity> findByUserUserId(int userId);

}
package com.hexaware.SimplyFly.Enums;

public enum BookingStatus {
	BOOKED,
	CANCELLED,
	PENDING

}
package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.PaymentDTO;
import com.hexaware.SimplyFly.Exceptions.BookingNotFoundException;
import com.hexaware.SimplyFly.Exceptions.PaymentNotFoundException;
import com.hexaware.SimplyFly.Models.BookingEntity;
import com.hexaware.SimplyFly.Models.PaymentEntity;
import com.hexaware.SimplyFly.Repositories.BookingRepository;
import com.hexaware.SimplyFly.Repositories.PaymentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private PaymentRepository paymentRepo;

    public PaymentDTO getPaymentByBookingId(int bookingId) {
        BookingEntity booking = bookingRepo.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException("Booking not found with ID: " + bookingId));

        PaymentEntity payment = paymentRepo.findByBooking(booking)
                .orElseThrow(() -> new PaymentNotFoundException("Payment not found for Booking ID: " + bookingId));

        PaymentDTO dto = new PaymentDTO();
        dto.setPaymentId(payment.getPaymentId());
        dto.setBookingId(bookingId);
        dto.setAmount(payment.getAmount());
        dto.setPaymentDate(payment.getPaymentDate());
        dto.setPaymentStatus(payment.getPaymentStatus());
        dto.setPaymentType(payment.getPaymentType());
        dto.setTransactionId(payment.getTransactionId());
        return dto;
    }
}

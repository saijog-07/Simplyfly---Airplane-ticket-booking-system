package com.hexaware.SimplyFly.Mappers;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.SimplyFly.DTO.FlightDTO;
import com.hexaware.SimplyFly.Models.FlightEntity;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.UserRepository;

@Component
public class FlightMapper {

	@Autowired(required = true)
	ModelMapper modelMapper;
	@Autowired
	private UserRepository userRepo;

	public FlightEntity DtoToFlight(FlightDTO dto) {
		FlightEntity entity = new FlightEntity();
		entity.setFlightId(dto.getFlightId());
		entity.setFlightNumber(dto.getFlightNumber());
		entity.setAirlineName(dto.getAirlineName());
		entity.setAvailSeats(dto.getAvailSeats());
		entity.setTotalSeats(dto.getTotalSeats());
		entity.setBaggage(dto.getBaggage());
		entity.setDepertureT(dto.getDepertureT());
		entity.setArrivalT(dto.getArrivalT());
		entity.setFare(dto.getFare());
		entity.setDestination(dto.getDestination());
		entity.setSource(dto.getSource());

		System.out.println("Flight number : " + dto.getFlightNumber());
		System.out.println("Owner id " + dto.getOwnerId());

		UserEntity owner = userRepo.findById(dto.getOwnerId())
				.orElseThrow(() -> new RuntimeException("Owner not found"));
		entity.setOwner(owner);

		return entity;
	}

	public FlightDTO FlightToDto(FlightEntity entity) {
		FlightDTO dto = new FlightDTO();
		dto.setFlightId(entity.getFlightId());
		dto.setFlightNumber(entity.getFlightNumber());
		dto.setAirlineName(entity.getAirlineName());
		dto.setAvailSeats(entity.getAvailSeats());
		dto.setTotalSeats(entity.getTotalSeats());
		dto.setBaggage(entity.getBaggage());
		dto.setDepertureT(entity.getDepertureT());
		dto.setArrivalT(entity.getArrivalT());
		dto.setFare(entity.getFare());
		dto.setDestination(entity.getDestination());
		dto.setSource(entity.getSource());

		dto.setOwnerId(entity.getOwner().getUserId());

		return dto;
	}

}
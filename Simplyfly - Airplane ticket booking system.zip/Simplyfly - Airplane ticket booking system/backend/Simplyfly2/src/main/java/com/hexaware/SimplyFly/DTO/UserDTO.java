package com.hexaware.SimplyFly.DTO;

import com.hexaware.SimplyFly.Enums.UserType;
import jakarta.validation.constraints.*;

public class UserDTO {

    private int userId;

    @NotBlank(message = "Email is required")
    @Email(message = "Enter a valid email")
    private String userEmail;

    @NotBlank(message = "User name is required")
    private String userName;

    @NotBlank(message = "Password is required")
    @Size(min = 8, message = "Password should be at least 8 characters long")
    private String userPwd;

    @Digits(integer = 10, fraction = 0, message = "Contact number must be 10 digits")
    @Min(value = 1000000000L, message = "Invalid contact number")
    @Max(value = 9999999999L, message = "Invalid contact number")
    private long userContact;

    @NotNull(message = "User type is required")
    private UserType userType;

    public UserDTO() {}

    public UserDTO(int userId, String userEmail, String userName, String userPwd, long userContact, UserType userType) {
        this.userId = userId;
        this.userEmail = userEmail;
        this.userName = userName;
        this.userPwd = userPwd;
        this.userContact = userContact;
        this.userType = userType;
    }

    // Getters and Setters

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPwd() {
        return userPwd;
    }

    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }

    public long getUserContact() {
        return userContact;
    }

    public void setUserContact(long userContact) {
        this.userContact = userContact;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "userId=" + userId +
                ", userEmail='" + userEmail + '\'' +
                ", userName='" + userName + '\'' +
                ", userPwd='" + userPwd + '\'' +
                ", userContact=" + userContact +
                ", userType=" + userType +
                '}';
    }
}

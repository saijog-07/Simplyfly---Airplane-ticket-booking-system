package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository userRepo;

    @Override
    public UserDetails loadUserByUsername(String userEmail) throws UsernameNotFoundException {
        UserEntity user = userRepo.findByuserEmail(userEmail);

        if (user == null) {
            throw new UsernameNotFoundException("User not found: " + userEmail);
        }

        String role = "ROLE_" + user.getUserType();
        List<SimpleGrantedAuthority> authorities = Collections.singletonList(new SimpleGrantedAuthority(role));

        return new org.springframework.security.core.userdetails.User(
                user.getUserEmail(),
                user.getUserPwd(),
                authorities
        );
    }
}

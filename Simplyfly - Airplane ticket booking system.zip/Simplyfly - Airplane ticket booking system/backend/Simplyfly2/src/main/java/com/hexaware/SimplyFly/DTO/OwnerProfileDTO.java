package com.hexaware.SimplyFly.DTO;

import lombok.Data;

@Data
public class OwnerProfileDTO {
    private int userId;
    private String userName;
    private String userEmail;
    private long userContact;
    private String airlineName;
    private String licenseNumber;
}

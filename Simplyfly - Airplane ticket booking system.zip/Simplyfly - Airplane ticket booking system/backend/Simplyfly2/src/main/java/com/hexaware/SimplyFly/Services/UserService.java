package com.hexaware.SimplyFly.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexaware.SimplyFly.DTO.ForgotPasswordDTO;
import com.hexaware.SimplyFly.DTO.LoginDTO;
import com.hexaware.SimplyFly.DTO.UserDTO;
import com.hexaware.SimplyFly.DTO.UserUpdateDTO;
import com.hexaware.SimplyFly.Exceptions.UserNotFoundException;
import com.hexaware.SimplyFly.Mappers.UserMapper;
import com.hexaware.SimplyFly.Models.OwnerEntity;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.OwnerRepository;
import com.hexaware.SimplyFly.Repositories.UserRepository;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Map;

import jakarta.validation.Valid;

@Service
public class UserService {

	@Autowired
	UserRepository userRepo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private OwnerRepository ownerRepo;

	@Autowired(required = true)
	UserMapper userMap;

	public UserDTO RegisterUserService(UserDTO udto) {

		UserEntity uEntity = userMap.DtoToUser(udto);

		if (udto.getUserPwd() != null) {
			String encoded = passwordEncoder.encode(udto.getUserPwd());
			uEntity.setUserPwd(encoded);
			System.out.println("Saving encoded password: " + encoded);
		}

		UserEntity uResult = userRepo.save(uEntity);

		UserDTO dtoResult = userMap.UserToDto(uResult);
		return dtoResult;
	}

	public UserDTO LoginUserService(@Valid LoginDTO ldto) {
		String email = ldto.getUserEmail();
		String pwd = ldto.getUserPassword();

		UserEntity user = userRepo.findByuserEmail(email);

		if (user != null) {
			if (user.getUserPwd().equals(pwd)) {
				UserDTO u = userMap.UserToDto(user);
				return u;
			}
		}
		throw new UserNotFoundException("User not found. Consider register.");
	}

	public UserDTO GetProfileService(int userId) {
		UserEntity u = userRepo.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("User " + userId + " not found"));
		UserDTO udto = userMap.UserToDto(u);
		return udto;
	}

	public UserDTO updateProfileFields(int userId, UserUpdateDTO updateDTO) {
		UserEntity user = userRepo.findById(userId)
				.orElseThrow(() -> new UserNotFoundException("User " + userId + " not found"));

		if (updateDTO.getUserName() != null && !updateDTO.getUserName().trim().isEmpty()) {
			user.setUserName(updateDTO.getUserName().trim());
		}

		if (updateDTO.getUserEmail() != null && !updateDTO.getUserEmail().trim().isEmpty()) {
			user.setUserEmail(updateDTO.getUserEmail().trim());
		}

		if (updateDTO.getUserContact() != null) {
			user.setUserContact(updateDTO.getUserContact());
		}

		UserEntity saved = userRepo.save(user);
		return userMap.UserToDto(saved);
	}

	public UserDTO forgotPasswordService(ForgotPasswordDTO dto) {
		String email = dto.getUserEmail();
		String username = dto.getUserName();

		UserEntity user = userRepo.findByuserEmail(email);
		if (user != null && user.getUserName().equals(username)) {
			user.setUserPwd(dto.getUserPwd());
			UserEntity saved = userRepo.save(user);
			return userMap.UserToDto(saved);
		}

		throw new UserNotFoundException("User " + username + " not found");
	}

	public List<UserDTO> getAllUsers() {
		List<UserEntity> users = userRepo.findAll();
		return users.stream()
				.map(userMap::UserToDto)
				.collect(Collectors.toList());
	}

	public UserEntity getUserByEmail(String userEmail) {
		return userRepo.findByuserEmail(userEmail);
	}

	public List<Map<String, Object>> getAllOwners() {
		List<OwnerEntity> owners = ownerRepo.findAllOwners();

		return owners.stream().map(owner -> {
			Map<String, Object> map = new HashMap<>();
			UserEntity user = owner.getUser();

			map.put("userId", user.getUserId());
			map.put("userName", user.getUserName());
			map.put("userEmail", user.getUserEmail());
			map.put("userContact", user.getUserContact());
			map.put("userType", user.getUserType().toString());

			map.put("airlineName", owner.getAirlineName());
			map.put("licenseNumber", owner.getLicenseNumber());

			return map;
		}).collect(Collectors.toList());
	}

}

package com.hexaware.SimplyFly.DTO;

import jakarta.validation.constraints.Email;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class UserUpdateDTO {

    private String userName;

    @Email(message = "Enter a valid email")
    private String userEmail;

    private Long userContact;


}

package com.hexaware.SimplyFly.Services;

import com.hexaware.SimplyFly.DTO.OwnerDTO;
import com.hexaware.SimplyFly.DTO.OwnerProfileDTO;
import com.hexaware.SimplyFly.Models.OwnerEntity;
import com.hexaware.SimplyFly.Models.UserEntity;
import com.hexaware.SimplyFly.Repositories.OwnerRepository;
import com.hexaware.SimplyFly.Repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OwnerService {

    @Autowired
    private OwnerRepository ownerRepository;

    @Autowired
    private UserRepository userRepository;

    public OwnerEntity registerOwner(OwnerDTO dto) throws Exception {
        UserEntity user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new Exception("User not found with ID: " + dto.getUserId()));

        OwnerEntity owner = new OwnerEntity();
        owner.setAirlineName(dto.getAirlineName());
        owner.setLicenseNumber(dto.getLicenseNumber());
        owner.setUser(user);

        return ownerRepository.save(owner);
    }

    public OwnerProfileDTO getOwnerProfile(int userId) throws Exception {
        UserEntity user = userRepository.findById(userId)
                .orElseThrow(() -> new Exception("User not found with ID: " + userId));

        OwnerEntity owner = ownerRepository.findByUserUserId(userId)
                .orElseThrow(() -> new Exception("Owner not found for user ID: " + userId));

        OwnerProfileDTO dto = new OwnerProfileDTO();
        dto.setUserId(user.getUserId());
        dto.setUserName(user.getUserName());
        dto.setUserEmail(user.getUserEmail());
        dto.setUserContact(user.getUserContact());
        dto.setAirlineName(owner.getAirlineName());
        dto.setLicenseNumber(owner.getLicenseNumber());

        return dto;
    }

}

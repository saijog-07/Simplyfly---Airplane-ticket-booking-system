package com.hexaware.SimplyFly.Models;

import java.time.LocalDate;
import java.util.List;

import com.hexaware.SimplyFly.Enums.BookingStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

@Entity
@Table(name="Booking")
public class BookingEntity {
	     @Id
	     @GeneratedValue(strategy=GenerationType.IDENTITY)
         private int bookingId;
	     
	     private LocalDate bookingDate = LocalDate.now();
	     
         @ManyToOne
         @JoinColumn(name = "flight_id", referencedColumnName = "FlightId")
         private FlightEntity flight;
         
         @ManyToOne
         @JoinColumn(name = "user_id", referencedColumnName = "userId")
         private UserEntity user;
         
         @Enumerated(EnumType.STRING)
         private BookingStatus Bookingstatus;
         
         private double totalFare;
         
         @OneToOne(mappedBy = "booking", cascade = CascadeType.ALL, orphanRemoval = true)
         private PaymentEntity payment;
         
         @OneToMany(mappedBy = "booking", cascade = CascadeType.ALL, orphanRemoval = true)
         private List<PassengerEntity> passengers;

}
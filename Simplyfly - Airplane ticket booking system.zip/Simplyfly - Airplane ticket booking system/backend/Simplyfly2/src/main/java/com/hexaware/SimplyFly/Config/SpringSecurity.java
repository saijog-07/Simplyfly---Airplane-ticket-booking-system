package com.hexaware.SimplyFly.Config;

import com.hexaware.SimplyFly.Filter.JwtFilter;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.*;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.*;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.*;
import org.springframework.security.web.*;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.*;

import java.util.List;

@Configuration
@EnableWebSecurity
public class SpringSecurity {

    private final JwtFilter jwtFilter;

    public SpringSecurity(JwtFilter jwtFilter) {
        this.jwtFilter = jwtFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .cors(Customizer.withDefaults())
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/register", "/api/auth/login", "/api/auth/register-owner",
                                "/api/auth/admin-register")
                        .permitAll()
                        .requestMatchers(HttpMethod.POST, "/api/auth/").hasAnyRole("OWNER", "USER", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/user/profile/").hasAnyRole("OWNER", "USER", "ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/user/profile/").hasAnyRole("OWNER", "USER", "ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/auth/forgotpwd").hasAnyRole("OWNER", "USER", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/admin/getusers").hasAnyRole("OWNER", "ADMIN")
                        .requestMatchers(HttpMethod.POST, "/api/flights/addFlight").hasAnyRole("ADMIN", "OWNER")
                        .requestMatchers(HttpMethod.POST, "/api/flights/search").hasAnyRole("OWNER", "USER", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/flights/{id}").hasAnyRole("OWNER", "USER", "ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/owner/flights/{id}").hasRole("OWNER")
                        .requestMatchers(HttpMethod.DELETE, "/api/owner/flights/{id}").hasRole("OWNER")
                        .requestMatchers(HttpMethod.GET, "/api/owner/flights/{ownerid}").hasAnyRole("ADMIN", "OWNER")
                        .requestMatchers(HttpMethod.POST, "/api/bookings").hasAnyRole("USER", "ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/bookings/user/{userId}")
                        .hasAnyRole("USER", "OWNER", "ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/bookings/{id}").hasRole("USER")
                        .requestMatchers(HttpMethod.DELETE, "/api/bookings/{id}").hasAnyRole("USER", "OWNER")
                        .requestMatchers(HttpMethod.GET, "/api/bookings/{id}/passengers").hasAnyRole("OWNER", "USER")
                        .requestMatchers(HttpMethod.GET, "/api/payments/{id}").hasRole("OWNER")

                      
                        .requestMatchers(HttpMethod.GET, "/api/flights/{id}/booked-seats")
                        .hasRole("OWNER")
                        .requestMatchers(HttpMethod.GET, "/api/bookings/flight/{flightid}")
                        .hasAnyRole("OWNER")
                        .requestMatchers(HttpMethod.GET, "/api/bookings/flightuser/{flightid}")
                        .hasAnyRole("USER")

                        .requestMatchers(HttpMethod.GET, "/api/admin/getOwners").hasAnyRole("ADMIN")
                        .requestMatchers(HttpMethod.GET, "/api/getAllFlight").hasAnyRole("ADMIN")

                        .anyRequest().authenticated())
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:3000")); 
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true); 

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}

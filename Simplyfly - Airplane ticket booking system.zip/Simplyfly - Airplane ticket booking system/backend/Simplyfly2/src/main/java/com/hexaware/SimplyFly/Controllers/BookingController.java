package com.hexaware.SimplyFly.Controllers;

import com.hexaware.SimplyFly.DTO.BookingDTO;
import com.hexaware.SimplyFly.DTO.BookingWithPaymentRequest;
import com.hexaware.SimplyFly.Services.BookingService;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @PostMapping
    public ResponseEntity<BookingDTO> createBooking(
            @Valid @RequestBody BookingWithPaymentRequest bookingRequest) {

        BookingDTO savedBooking = bookingService.createBooking(
                bookingRequest.getBookingDTO(),
                bookingRequest.getPaymentDTO());

        return ResponseEntity.ok(savedBooking);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<BookingDTO>> getBookingsByUser(@PathVariable int userId) {
        List<BookingDTO> bookings = bookingService.getBookingsByUserId(userId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookingDTO> getBookingById(@PathVariable int id) {
        BookingDTO booking = bookingService.getBookingById(id);
        return ResponseEntity.ok(booking);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBooking(@PathVariable int id) {
        bookingService.deleteBookingById(id);
        return ResponseEntity.ok("Booking cancelled successfully.");
    }

    @GetMapping("/flight/{flightId}")
    public ResponseEntity<List<BookingDTO>> getBookingsByFlight(@PathVariable int flightId) {
        List<BookingDTO> bookings = bookingService.getBookingsByFlightId(flightId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/flightuser/{flightId}")
    public ResponseEntity<List<BookingDTO>> getBookingsByFlightId(@PathVariable int flightId) {
        List<BookingDTO> bookings = bookingService.getBookingsByFlightIdUser(flightId);
        return ResponseEntity.ok(bookings);
    }

    @PutMapping("/cancelbooking/{bookingId}")
    public ResponseEntity<String> cancelBooking(@PathVariable int bookingId) {
        bookingService.cancelBookingById(bookingId);
        return ResponseEntity.ok("Booking status updated to CANCELLED successfully.");
    }

}

package com.hexaware.SimplyFly.Enums;

public enum PaymentType {
	UPI,
	CARD
}
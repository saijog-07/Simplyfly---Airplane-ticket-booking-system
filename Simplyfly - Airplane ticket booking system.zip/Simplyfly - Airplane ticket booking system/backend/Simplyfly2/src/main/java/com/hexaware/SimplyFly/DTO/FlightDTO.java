package com.hexaware.SimplyFly.DTO;

import java.time.LocalDateTime;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FlightDTO {

	private int flightId;

	@NotBlank(message = "Flight number is required")
	private String flightNumber;

	@NotBlank(message = "Airline name is required")
	private String airlineName;

	private int ownerId;

	@Min(value = 0, message = "Available seats cannot be negative")
	private int availSeats;

	@Min(value = 1, message = "Total seats must be at least 1")
	private int totalSeats;

	private String baggage;

	private LocalDateTime depertureT;
	private LocalDateTime arrivalT;

	@Min(value = 0, message = "Fare cannot be negative")
	private double fare;

	@NotBlank(message = "Destination is required")
	private String destination;

	@NotBlank(message = "Source is required")
	private String source;
}
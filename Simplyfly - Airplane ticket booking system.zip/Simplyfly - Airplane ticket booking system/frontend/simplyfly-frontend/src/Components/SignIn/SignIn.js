import { LockOutlined, UserOutlined } from '@ant-design/icons';
import {
  Button,
  Checkbox,
  Form,
  Input,
  Typography,
  Modal,
  Flex,
} from 'antd';
import { useDispatch } from 'react-redux';
import axios from 'axios';
import { API_BASE_URL } from '../../apiConfig';
import { Link, useNavigate } from 'react-router-dom';
import { setUser } from '../../Store/authSlice';

const { Title, Text } = Typography;

const SignIn = () => {
  const dispatch = useDispatch();
  const nav = useNavigate();

  const onFinish = async (values) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/api/auth/login`, {
        userEmail: values.email,
        userPassword: values.password,
      });

      const token = response.data;

      localStorage.setItem('token', token);

      const decodedPayload = JSON.parse(atob(token.split('.')[1]));
      dispatch(setUser(decodedPayload));

      alert('Login successful!');

      if (decodedPayload.userType === 'OWNER') {
        nav('/ownerhome');
      } else if (decodedPayload.userType === 'ADMIN') {
        nav('/adminhome');
      } else {
        nav('/Home');
      }
    } catch (error) {
      console.error('Login failed:', error);
      alert('Invalid email or password!');
    }
  };

  const handleCancel = () => {
    nav('/');
  };

  return (
    <Modal
      open={true}
      onCancel={handleCancel}
      footer={null}
      centered
      closable={false}
      bodyStyle={{
        padding: '30px',
        borderRadius: '10px',
        background: '#f9f9f9',
      }}
    >
      <div style={{ textAlign: 'center', marginBottom: 25 }}>
        <Title level={3} style={{ marginBottom: 5, color: '#605DEC' }}>
          Sign in to SimplyFly
        </Title>
        <Text type="secondary">Welcome back! Please login to continue.</Text>
      </div>

      <Form
        name="login"
        layout="vertical"
        onFinish={onFinish}
        initialValues={{ remember: true }}
        style={{ maxWidth: 400, margin: '0 auto' }}
      >
        <Form.Item
          name="email"
          label="Email"
          rules={[{ required: true, message: 'Please input your Email!' }]}
        >
          <Input
            prefix={<UserOutlined />}
            placeholder="Enter your email"
            size="large"
          />
        </Form.Item>

        <Form.Item
          name="password"
          label="Password"
          rules={[{ required: true, message: 'Please input your Password!' }]}
        >
          <Input.Password
            prefix={<LockOutlined />}
            placeholder="Enter your password"
            size="large"
          />
        </Form.Item>

        <Form.Item>
          <Flex justify="space-between" align="center">
            <Form.Item name="remember" valuePropName="checked" noStyle>
              <Checkbox>Remember me</Checkbox>
            </Form.Item>
            <a href="#" style={{ color: '#605DEC' }}>
              Forgot password?
            </a>
          </Flex>
        </Form.Item>

        <Form.Item>
          <Button
            block
            type="primary"
            htmlType="submit"
            size="large"
            style={{
              backgroundColor: '#605DEC',
              borderRadius: 5,
              fontWeight: 600,
            }}
          >
            Log In
          </Button>
        </Form.Item>

        <div style={{ textAlign: 'center' }}>
          <Text>Don't have an account? </Text>
          <Link to="/signUp" style={{ color: '#605DEC', fontWeight: 500 }}>
            Register now!
          </Link>
        </div>
      </Form>
    </Modal>
  );
};

export default SignIn;
